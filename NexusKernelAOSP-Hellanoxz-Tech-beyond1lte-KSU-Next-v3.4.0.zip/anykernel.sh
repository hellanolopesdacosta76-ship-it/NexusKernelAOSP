### AnyKernel3 Ramdisk Mod Script
## NexusKernelAOSP-Hellanoxz Tech

properties() {
'
kernel.string=NexusKernelAOSP-Hellanoxz Tech
do.devicecheck=1
do.modules=0
do.systemless=0
do.cleanup=1
do.cleanuponabort=1
device.name1=beyond1lte
supported.versions=14 - 16
';
}

boot_attributes() {
set_perm_recursive 0 0 755 644 $RAMDISK/*;
set_perm_recursive 0 0 750 750 $RAMDISK/init* $RAMDISK/sbin;
}

BLOCK=/dev/block/by-name/boot;
IS_SLOT_DEVICE=0;
RAMDISK_COMPRESSION=auto;
PATCH_VBMETA_FLAG=auto;

. tools/ak3-core.sh;

dump_boot;

write_boot;
